package com.example.listviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView myListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myListView = findViewById(R.id.listViewAnimals);

        ArrayList<String> animals = new ArrayList<>();
        animals.add("Cat");
        animals.add("Dog");
        animals.add("Camel");
        animals.add("Tiger");
        animals.add("Crocodile");
        animals.add("Giraffe");
        animals.add("Lemur");
        animals.add("Leopard");
        animals.add("Zebra");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,animals);

        myListView.setAdapter(arrayAdapter);

//        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener())
}

        {







    }
}