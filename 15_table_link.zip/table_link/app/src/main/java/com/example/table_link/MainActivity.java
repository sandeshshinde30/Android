package com.example.table_link;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find TextViews by their IDs
        TextView javaTextView = findViewById(R.id.javaTextView);
        TextView pythonTextView = findViewById(R.id.pythonTextView);
        TextView cplusplusTextView = findViewById(R.id.cplusplusTextView);

        // Set onClickListeners for each TextView
        javaTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLink("https://www.java.com");
            }
        });

        pythonTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLink("https://www.python.org");
            }
        });

        cplusplusTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLink("https://www.cplusplus.com");
            }
        });
    }

    // Method to open links
    private void openLink(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }
    }
